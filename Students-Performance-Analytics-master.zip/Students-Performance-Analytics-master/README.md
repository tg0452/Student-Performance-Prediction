# Student-s-Performance-Analytics
Students Performance Evaluation using Feature Engineering, Feature Extraction, Manipulation of Data, Data Analysis, Data Visualization and at lat applying Classification Algorithms from Machine Learning to Separate Students with different grades

# Description


# Context
Marks secured by the students in different subjects like
1. Maths
2. English
3. Science
with some other important credentials related to academics

# Content
This data set consists of the marks secured by the students in various subjects.

# Acknowledgements
http://roycekimmons.com/tools/generated_data/exams

# Inspiration
To understand the influence of the parents background, test preparation etc on students performance
